<?php
const APP_PATH = '/Shock88/';
const HOST = 'localhost';
const USER = 'root';
const PASS = '@Osc4r4rz4t3';
const DB = 'p_nort';
const CHARSET = 'charset=utf8mb4';

const USER_SMTP = 'correo';
const PASS_SMTP = 'clave correo';
const PUERTO_SMTP = 465;
const HOST_SMTP = 'host';
